Hafiz Royal Collection - Free Static Website

1. Open index.html to preview the website.
2. Replace "YOUR NUMBER HERE" and "YOUR SHOP ADDRESS HERE" in index.html.
3. Upload the whole folder to a free static hosting service such as GitHub Pages or Netlify.
4. Keep the images folder together with index.html.

The site is mobile-friendly and uses the uploaded clothing images.
